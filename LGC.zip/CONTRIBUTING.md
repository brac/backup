# How to contribute to Learners Guild's curriculum


## Did you find a bug?

Please submit a [GitHub Issue](https://github.com/GuildCrafts/curriculum/issues/new?&body=%23+Bug+Report%0A%0A)


## Did you find a typo or spelling mistake?

Please submit a [Pull Request](https://github.com/GuildCrafts/curriculum/pulls)


## Do you want to request a new feature?

Please submit a [GitHub Issue](https://github.com/GuildCrafts/curriculum/issues/new?&body=%23+Feature+Request%0A%0A)
