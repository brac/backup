# Phase 3 Development

## Potential Goals For This Phase

- #??? _Authentication Goal_
- #226 Trossello Labels Epic
- #378 Socket.io Party Chat
- Queues
  - TODO: learn queues from event loops
  - TODO: simulate a bank with adding and removing tellers
  - TODO: build a background job system

## Unsorted Resources

- https://www.thoughtworks.com/insights/blog/effective-navigation-in-pair-programming
- https://expressjs.com/en/advanced/best-practice-performance.html
