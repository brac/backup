# Phase 4 Development

Other projects to consider:

https://github.com/MunGell/awesome-for-beginners
https://www.codetriage.com/?language=JavaScript

https://github.com/HabitRPG/habitica
https://github.com/request/request
https://github.com/callemall/material-ui

## Misc Resources

https://medium.com/@kentcdodds/first-timers-only-78281ea47455
https://github.com/search?utf8=%E2%9C%93&q=label%3Afirst-timers-only+is%3Aopen&type=Issues&ref=searchresults

http://up-for-grabs.net/#/tags/javascript
