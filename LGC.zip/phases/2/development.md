# Phase 2 Development

<!--

- meet with each learner once a week for 20m to assess progress
  - this shakes out to about 2 hours a day to meet 1-1
- clarity on modules
- Di and Ethan are coaches for phase 1 and 2
- learners place a `i need help` indicator on their monitor
 -->
