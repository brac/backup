# Phase 0

Phase 0 happens before you get to the guild. The details of this phase are
[Currently described here](https://guide.learnersguild.org/Runway/)
