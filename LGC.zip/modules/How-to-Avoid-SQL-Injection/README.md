# How to Avoid SQL Injection

## Skills

- Can describe what SQL injection is
- Can describe what a SQL parameterized query (or prepared statement) is
