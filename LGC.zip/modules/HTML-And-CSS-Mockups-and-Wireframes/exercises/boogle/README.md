# Boogle

Create a new directory and repository with the following files:

```
/home-page.html
/product-details-page.html
/scrollable-column-page.html
/shared.css
```

then create pages based on the wireframes below as best you can.


## Homepage

![boogle](./MockupBoogle.png)


## Product Detail Page

![product page](./MockupProduct.png)


## Scrollable Column Page

![scrollable column page](./Mockup3Column.png)
