# Theoretical Programming

[This article](https://auth0.com/blog/glossary-of-modern-javascript-concepts) links to a ton of amazing reading




- [Imperative vs. Declarative Programming](https://tylermcginnis.com/imperative-vs-declarative-programming/)
