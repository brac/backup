# What is an SQL Transaction?

## Skills

- Can describe a SQL transaction
- Can describe a situation that would call for a SQL transaction
- Can describe what `COMMIT` and `ROLLBACK` mean in SQL
- Can describe what an atomic operation is in SQL
