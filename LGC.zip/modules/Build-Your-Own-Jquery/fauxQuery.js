const fauxQuery = selector => {
  // Implement the selection logic here, 
  // to return an array of matching FauxQuery objects
}

module.exports = fauxQuery