# Problem Decomposition


## Search Terms

```
programming problem decomposition
```

## Resources

### Watch

- https://www.youtube.com/watch?v=yQVTijX437c
- https://www.youtube.com/watch?v=63BBWWsqsT0

### Reading

- http://www.thinkingparallel.com/2007/09/06/how-to-split-a-problem-into-tasks/
- http://www.programmingforbiologists.org/material/problem-decomposition/
- http://www.cs.oswego.edu/~blue/xhx/books/csjs/problemsolvingpatterns/section01/main.html
- https://en.wikipedia.org/wiki/Decomposition_(computer_science)
