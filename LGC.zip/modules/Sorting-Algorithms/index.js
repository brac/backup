function bubbleSort( array ) {

}

function selectionSort( array ) {

}

function insertionSort( array ) {

}

/*
 * Validate your sorting implementation by calling your functions on the
 * input, below, and comparing their results to the results of using JavaScript's
 * Array.prototype.sort()
 */
var testInput = [ 9, 3, 1, 2, 1000, 15, 83, 75, 84, 200000, 42 ]
